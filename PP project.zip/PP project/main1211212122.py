import pygame
import sqlite3

clock = pygame.time.Clock()
pygame.init()
label = pygame.font.Font('PYGAME FONTS/Roboto-Black.ttf', 40)
label1 = pygame.font.Font('PYGAME FONTS/Roboto-Black.ttf', 30)

hel_text = label1.render('Добро пожаловать в игру!', False, (115, 132, 148))
start_text = label1.render('Начало', False, (193, 196, 199))
exit_text = label1.render('Выйти из игры :(', False, (193, 196, 199))

start_label_rect = start_text.get_rect(topleft=(200, 155))
exit_label_rect = exit_text.get_rect(topleft=(125, 260))


def start_screen():
    pygame.init()
    screen1 = pygame.display.set_mode((500, 500))
    screen1.fill('black')

    screen1.blit(hel_text, (70, 50))
    screen1.blit(start_text, start_label_rect)

    screen1.blit(exit_text, exit_label_rect)

    st = True

    while st:
        mouse1 = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                st = False

        if exit_label_rect.collidepoint(mouse1) and pygame.mouse.get_pressed()[0]:
            pygame.quit()
            st = False
        elif start_label_rect.collidepoint(mouse1) and pygame.mouse.get_pressed()[0]:
            return

        pygame.display.flip()
        clock.tick(30)


start_screen()

screen = pygame.display.set_mode((1280, 720))

pygame.display.set_caption("PYgAme")

lose_label = label.render('Вы проиграли!', False, (193, 196, 199))
restart_label = label.render('Играть заново', False, (115, 132, 148))
restart_label_rect = restart_label.get_rect(topleft=(500, 400))

to_menu_label = label.render('Выйти из игры)', False, (115, 132, 148))
to_menu_label_rect = restart_label.get_rect(topleft=(500, 500))

icon = pygame.image.load("PYGAME MEDIA/Icon1.png")
pygame.display.set_icon(icon)

ninja = pygame.image.load("PYGAME MEDIA/ninja1.png").convert_alpha()

bg = pygame.image.load('PYGAME MEDIA/BG.png').convert()

walk_left = [
    pygame.image.load('PYGAME MEDIA/pL/pL1.png').convert_alpha(),
    pygame.image.load('PYGAME MEDIA/pL/pL2.png').convert_alpha(),
    pygame.image.load('PYGAME MEDIA/pL/pL3.png').convert_alpha(),
    pygame.image.load('PYGAME MEDIA/pL/pL4.png').convert_alpha(),
]

walk_right = [
    pygame.image.load('PYGAME MEDIA/pR/pR1.png').convert_alpha(),
    pygame.image.load('PYGAME MEDIA/pR/pR2.png').convert_alpha(),
    pygame.image.load('PYGAME MEDIA/pR/pR3.png').convert_alpha(),
    pygame.image.load('PYGAME MEDIA/pR/pR4.png').convert_alpha(),
]

bullet = pygame.image.load('PYGAME MEDIA/bullet.png')
bullets = []

suric_x = 0

ninja_list_in_game = []

player_speed = 5
player_x = 150
player_y = 570

all_timer = 0
medium_timer = 0
last_timer = 0

is_jump = False
jump_count = 7

player_anim_count = 0
suric_anim_count = 0
bg_x = 0

waves = 1
lst_wave = 1

ninja_SP = 10

mobs_count = 1
mobs_spawned = 0
mobs_left = 0

# bg_sound = pygame.mixer.Sound('PYGAME MEDIA/BGSound (2).mp3')
# bg_sound.play()

ninja_timer = pygame.USEREVENT + 1
bullets_timer = pygame.USEREVENT + 1
# pygame.time.set_timer(ninja_timer, 1000)
pygame.time.set_timer(bullets_timer, 25000)
bullets_left = 5

gameplay = True

running = True

while running:
    waves_label = label.render(f'Волна: {waves}', False, (115, 132, 148))
    bullets_left_label = label.render(f'Потронов осталось: {bullets_left}', False, (99, 120, 95))
    screen.blit(bg, (bg_x, 0))
    screen.blit(bg, (bg_x + 1280, 0))
    screen.blit(bullets_left_label, (0, 0))
    screen.blit(waves_label, (0, 50))

    if gameplay:

        player_rect = walk_left[0].get_rect(topleft=(player_x, player_y))

        if ninja_list_in_game:
            for (i, el) in enumerate(ninja_list_in_game):
                screen.blit(ninja, el)
                el.x -= ninja_SP

                if el.x < -50:
                    ninja_list_in_game.pop(i)

                if player_rect.colliderect(el):
                    gameplay = False

        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            screen.blit(walk_left[player_anim_count], (player_x, player_y))
        else:
            screen.blit(walk_right[player_anim_count], (player_x, player_y))

        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        elif keys[pygame.K_RIGHT] and player_x < 1240:
            player_x += player_speed

        if not is_jump:
            if keys[pygame.K_SPACE]:
                is_jump = True

        else:
            if jump_count >= -7:
                if jump_count > 0:
                    player_y -= (jump_count ** 2) / 2
                else:
                    player_y += (jump_count ** 2) / 2
                jump_count -= 1
            else:
                is_jump = False
                jump_count = 7

        if player_anim_count == 3:
            player_anim_count = 0
        else:
            player_anim_count += 1

        bg_x -= 2
        if bg_x == -1280:
            bg_x = 0

        if bullets:
            for (i, el) in enumerate(bullets):
                screen.blit(bullet, (el.x, el.y))
                el.x += 4

                if el.x > 1280:
                    bullets.pop(i)

                if ninja_list_in_game:
                    for (index, nin) in enumerate(ninja_list_in_game):
                        if el.colliderect(nin):
                            ninja_list_in_game.pop(index)
                            bullets.pop(i)
                            mobs_left -= 1

        all_timer += 1

        if all_timer >= 150:
            medium_timer += 1
            if medium_timer >= 20 and mobs_spawned <= mobs_count:
                ninja_list_in_game.append(ninja.get_rect(topleft=(1320, 570)))
                mobs_left += 1
                mobs_spawned += 1
                medium_timer = 0

            if mobs_spawned > mobs_count:
                mobs_spawned = 0
                mobs_count += 1
                all_timer = 0
                ninja_SP += 5
                waves += 1

    else:
        screen.fill((87, 88, 89))
        screen.blit(lose_label, (500, 300))
        screen.blit(restart_label, restart_label_rect)
        screen.blit(to_menu_label, to_menu_label_rect)

        mouse = pygame.mouse.get_pos()
        if restart_label_rect.collidepoint(mouse) and pygame.mouse.get_pressed()[0]:
            gameplay = True
            player_x = 150
            bullets_left = 5
            ninja_list_in_game.clear()
            bullets.clear()
            mobs_left = 0
            mobs_spawned = 0
            medium_timer = 0
            all_timer = 0
            mobs_count = 1
            ninja_SP = 10
            if lst_wave < waves:
                lst_wave = waves
            waves = 1

        if to_menu_label_rect.collidepoint(mouse) and pygame.mouse.get_pressed()[0]:
            pygame.quit()

    pygame.display.update()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()

        if event.type == bullets_timer:
            bullets_left += 5
        if gameplay and event.type == pygame.KEYUP and event.key == pygame.K_b and bullets_left > 0:
            bullets.append(bullet.get_rect(topleft=(player_x + 30, player_y + 10)))
            bullets_left -= 1

    clock.tick(20)
